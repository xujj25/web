﻿#Readme

---

该作品是本人的Web2.0作业PuzzleGame[（具体需求说明）][1]。运行html文件夹下的html文件即可。


  [1]: http://my.ss.sysu.edu.cn/wiki/display/WEB/Homework+7.+Fifteen+Puzzle